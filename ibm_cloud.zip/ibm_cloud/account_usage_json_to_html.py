import json

# Load the JSON file
with open("./account_usage.json", "r") as file:
    data = json.load(file)

# Extract key details
billing_country = data.get("billing_country", "N/A")
currency = data.get("currency_code", "N/A")
month = data.get("month", "N/A")
resources = data.get("resources", [])

# Start HTML content
html_content = f"""
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        h2 {{ color: #007BFF; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #007BFF; color: white; }}
    </style>
</head>
<body>
    <h2>IBM Cloud Usage Report - {month}</h2>
    <p><strong>Billing Country:</strong> {billing_country}</p>
    <p><strong>Currency:</strong> {currency}</p>

    <h3>Resource Cost Breakdown</h3>
    <table>
        <tr>
            <th>Resource Name</th>
            <th>Billable Cost ({currency})</th>
            <th>Billable Rated Cost ({currency})</th>
            <th>Non Billable Cost ({currency})</th>
            <th>Non Billable Rated Cost ({currency})</th>
            <th>Usage Details</th>
        </tr>
"""

# Process each resource
for resource in resources:
    resource_name = resource.get("resource_id", "Unknown Resource")
    billable_cost = resource.get("billable_cost", 0)
    billable_rated_cost = resource.get("billable_rated_cost", 0)
    non_billable_cost = resource.get("non_billable_cost", 0)
    non_billable_rated_cost = resource.get("non_billable_rated_cost", 0)
    
    # Extract usage details
    usage_details = []
    for plan in resource.get("plans", []):
        for usage in plan.get("usage", []):
            metric = usage.get("metric", "Unknown Metric")
            quantity = usage.get("quantity", 0)
            unit = usage.get("unit", "")
            usage_details.append(f"{quantity:.2f} {unit} ({metric})")
    
    usage_text = "<br>".join(usage_details) if usage_details else "No Usage Data"

    html_content += f"""
        <tr>
            <td>{resource_name}</td>
            <td>${billable_cost:.2f}</td>
            <td>${billable_rated_cost:.2f}</td>
            <td>${non_billable_cost:.2f}</td>
            <td>${non_billable_rated_cost:.2f}</td>
            <td>{usage_text}</td>
        </tr>
    """

html_content += """
    </table>
    <p>Regards,</p>
    <p><b>IBM Cloud Cost Monitoring System</b></p>
</body>
</html>
"""

# Save HTML file
with open("account_usage_report.html", "w") as output_file:
    output_file.write(html_content)

print("✅ HTML report generated successfully!")
