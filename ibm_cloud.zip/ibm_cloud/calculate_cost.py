import requests
import smtplib
import json
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# IBM Cloud API Key and Account ID
IBM_CLOUD_API_KEY = "uhjd69aU63YjEpIBJYNCcHEMLI3BWyh3gOYGPPX1NEPc"
ACCOUNT_ID = "6a9b18b8d05a4b6392a8c9ef9a064505"

# Email Configuration
SMTP_SERVER = "smtp.gmail.com"  # Change for different providers
SMTP_PORT = 587
EMAIL_SENDER = "pavankumar.ambuga@gmail.com"
EMAIL_PASSWORD = "1ag9drm8rb9"
EMAIL_RECEIVER = "pavan.govindraj@ibm.com"

# IBM Cloud Cost API Endpoint
COST_API_URL = f"https://billing.cloud.ibm.com/v4/accounts/{ACCOUNT_ID}/usage"

# Function to get IBM Cloud costs
def get_ibm_cloud_costs():
    headers = {
        "Authorization": f"Bearer {IBM_CLOUD_API_KEY}",
        "Content-Type": "application/json"
    }
    response = requests.get(COST_API_URL, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(response.json())
        return None

# Function to send email report
def send_email_report(cost_data):
    msg = MIMEMultipart()
    msg["From"] = EMAIL_SENDER
    msg["To"] = EMAIL_RECEIVER
    msg["Subject"] = "IBM Cloud Daily Cost Report"

    # Format the cost data for email
    cost_summary = json.dumps(cost_data, indent=4)
    email_body = f"Here is your IBM Cloud cost report for today:\n\n{cost_summary}"
    
    msg.attach(MIMEText(email_body, "plain"))

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
        server.quit()
        print("Email sent successfully!")
    except Exception as e:
        print(f"Error sending email: {e}")

# Main Execution
cost_data = get_ibm_cloud_costs()
if cost_data:
    send_email_report(cost_data)
else:
    print("Failed to retrieve IBM Cloud cost data.")
