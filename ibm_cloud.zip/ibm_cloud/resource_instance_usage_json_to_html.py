import json

# Load the JSON file
with open("./resources_instance_usage.json", "r") as file:
    data = json.load(file)

# Extract key details
month = data.get("resources", [])[0].get("month", "N/A")
currency = data.get("resources", [])[0].get("currency_code", "USD")

# Start HTML content
html_content = f"""
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        h2 {{ color: #007BFF; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #007BFF; color: white; }}
    </style>
</head>
<body>
    <h2>IBM Cloud Resource Usage Report - {month}</h2>
    <p><strong>Currency:</strong> {currency}</p>

    <h3>Resource Cost Breakdown</h3>
    <table>
        <tr>
            <th>Resource Name</th>
            <th>Usage Metric</th>
            <th>Quantity</th>
            <th>Billable Cost ({currency})</th>
            <th>Discounts Applied</th>
        </tr>
"""

# Process each resource
for resource in data.get("resources", []):
    resource_name = resource.get("resource_id", "Unknown Resource")
    for usage in resource.get("usage", []):
        metric = usage.get("metric", "N/A")
        unit = usage.get("unit", "N/A")
        quantity = usage.get("quantity", 0)
        cost = usage.get("cost", 0)

        discounts = ""
        for discount in usage.get("discounts", []):
            discounts += discount.get("name", "Unknown Discount") + "->" + str(discount.get("discount", 0)) + "%" + "<br>"
        if not discounts:
            discounts = "None"

        html_content += f"""
        <tr>
            <td>{resource_name}</td>
            <td>{metric} ({unit})</td>
            <td>{quantity:.2f}</td>
            <td>${cost:.2f}</td>
            <td>{discounts}</td>
        </tr>
        """

html_content += """
    </table>
    <p>Regards,</p>
    <p><b>IBM Cloud Cost Monitoring System</b></p>
</body>
</html>
"""

# Save HTML file
with open("resource_usage_report.html", "w") as output_file:
    output_file.write(html_content)

print("✅ HTML report generated successfully!")
