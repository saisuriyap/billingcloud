import requests
import json


# Define the IAM token generation function
def get_iam_token():
    print("=====Entering Token generation phase=======")
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = f"grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey={IBM_CLOUD_API_KEY}"
    
    response = requests.post(IAM_TOKEN_URL, headers=headers, data=data)
    if response.status_code == 200:
        print("=====PASS: Exiting Token generation phase=======")
        return response.json()["access_token"]
    else:
        print(f"Error fetching IAM token: {response.status_code}")
        print(response.text)
        print("=====FAIL: Exiting Token generation phase=======")
        return None

# Replace with your actual IBM Cloud API Key
IBM_CLOUD_API_KEY = "qBheXSx2n3NrLv5w2SmyhVk6QOUjKd4k0H7cSPfEfpS-"
IAM_TOKEN_URL = 'https://iam.cloud.ibm.com/identity/token'

# Fetch IAM token
IAM_TOKEN = get_iam_token()

if IAM_TOKEN:
    # Set the resource_id to "is.vpc"
    resource_id = "3042af920bb7428fb5e60fbb2250fe5c"

    # Construct the URL for resource_instances API
    resource_instances_url = f'https://resource-controller.cloud.ibm.com/v2/resource_instances/{resource_id}'
    
    # Send GET request to fetch the data
    resource_instances_response = requests.get(
        resource_instances_url,
        headers={
            'Authorization': f'Bearer {IAM_TOKEN}',
            'Accept': 'application/json'
        }
    )

    if resource_instances_response.status_code == 200:
        # Get the JSON response
        resource_instances_data = resource_instances_response.json()

        # Print the response to verify (optional)
        print("Resource Instances Data:", resource_instances_data)

        # Save the JSON response to a file
        with open('resource_instances_data.json', 'w') as json_file:
            json.dump(resource_instances_data, json_file, indent=4)

        print("JSON data saved to 'resource_instances_data.json'")
    else:
        print(f"Failed to get resource instances data. Status code: {resource_instances_response.status_code}")
else:
    print("Failed to obtain IAM token.")
