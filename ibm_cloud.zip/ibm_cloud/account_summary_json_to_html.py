import json

# Load the JSON file
with open("./account_summary.json", "r") as file:
    data = json.load(file)

# Extract relevant details
account_id = data.get("account_id", "N/A")
month = data.get("month", "N/A")
billable_cost = data["resources"].get("billable_cost", 0)
non_billable_cost = data["resources"].get("non_billable_cost", 0)
currency = data.get("billing_currency_code", "N/A")
resources = data.get("account_resources", [])

# Generate HTML
html_content = f"""
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; color: #333; }}
        h2 {{ color: #007BFF; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #007BFF; color: white; }}
    </style>
</head>
<body>
    <h2>IBM Cloud Cost Report - {month}</h2>
    <p><strong>Account ID:</strong> {account_id}</p>
    <p><strong>Total Billable Cost:</strong> ${billable_cost:.2f} {currency}</p>
    <p><strong>Non-Billable Cost:</strong> ${non_billable_cost:.2f} {currency}</p>
    
    <h3>Resource Cost Breakdown</h3>
    <table>
        <tr>
            <th>Resource Name</th>
            <th>Billable Cost ({currency})</th>
            <th>Discounts Applied</th>
        </tr>
"""

# Loop through resources and add table rows
for resource in resources:
    resource_name = resource.get("resource_name", "Unknown")
    cost = resource.get("billable_cost", 0)
    

    discounts = ""
    for discount in resource.get("discounts", []):
        discounts += discount.get("name", "Unknown Discount") + "->" + str(discount.get("discount", 0)) + "%" + "<br>"
    if not discounts:
        discounts = "None"

    html_content += f"""
        <tr>
            <td>{resource_name}</td>
            <td>${cost:.2f}</td>
            <td>{discounts}</td>
        </tr>
    """

html_content += """
    </table>
    <p>Regards,</p>
    <p><b>IBM Cloud Cost Monitoring System</b></p>
</body>
</html>
"""

# Save the HTML report
with open("account_summary.html", "w") as output_file:
    output_file.write(html_content)

print("✅ HTML report generated successfully!")
